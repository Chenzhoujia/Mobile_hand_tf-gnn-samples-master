# TensorBoard Dev Summit Tutorial

This contains a runnable code companion to the TensorBoard tutorial at the 
2017 TensorFlow Dev Summit.

You can watch the tutorial [on YouTube](https://www.youtube.com/watch?v=eBbEDRsCmv4&t=1105s).

Happy TensorBoarding!